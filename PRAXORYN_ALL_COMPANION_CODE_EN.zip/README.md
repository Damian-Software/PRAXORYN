# PRAXORYN — Complete English Source Package

This package contains 13 original laboratory projects accompanying PRAXORYN, plus an English-language consolidated source archive. It includes book-referenced archive names so readers can follow the instructions without searching for renamed files.

START HERE:
1. Choose the named lab archive referenced in the book.
2. Extract it in a new empty directory and read its README.md.
3. Use synthetic inputs; run the offline tests before connecting a real model.
4. Never expose a demonstration endpoint publicly without separate authentication, authorization and security review.

Repository: https://github.com/Damian-Software/PRAXORYN

The alias PRAXORYN_MEDIAOPS_LAB_01.zip contains the same MediaOps project as PRAXORYN_SVAZEK_III_LAB_01.zip. The English Field Kit archive contains translated synthetic cases 487–518; all Python CLI modules are original and testable.

To import the consolidated source archive into a locally cloned repository:
python3 tools/import_companion_bundle.py PRAXORYN_COMPLETE_COMPANION_SOURCES_EN.zip
python3 tools/import_companion_bundle.py PRAXORYN_COMPLETE_COMPANION_SOURCES_EN.zip --apply

Publication note: the sample applications are teaching labs, not independently audited production software. Mock outputs are labeled and do not establish real GPU/model performance.
