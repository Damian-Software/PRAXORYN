# PRAXORYN — Complete English Companion Sources

Author: Damián Zelený. Book: PRAXORYN (Czech edition).

This package contains the original companion laboratories supplied with the book, consolidated into one navigable archive. Source code, instructions, and synthetic examples are in English. The Czech-language manuscript itself is not included.

## Start here

1. Choose a lab from `labs/` below.
2. Enter its extracted project directory, usually one level below the lab folder.
3. Read that project's `README.md` before installing dependencies.
4. Run its offline unit tests first; only then connect an existing local model API.
5. Do not use production customer data or expose lab endpoints to the internet.

| Book laboratory | Directory inside this bundle |
|---|---|
| LOCAL_AI_SVAZEK_II_LAB_01.zip | `labs/v2_01_provider_api/` |
| LOCAL_AI_SVAZEK_II_LAB_02.zip | `labs/v2_02_corporate_rag/` |
| LOCAL_AI_SVAZEK_II_LAB_03.zip | `labs/v2_03_email_crm_workflows/` |
| LOCAL_AI_SVAZEK_II_LAB_04.zip | `labs/v2_04_enterprise_workshops/` |
| CASE_DESK_LAB_05.zip | `labs/v2_05_casedesk/` |
| PRAXORYN_FIELDKIT_LAB_06.zip | `labs/v2_06_aiops_fieldkit/` |
| PRAXORYN_SVAZEK_II_LAB_07.zip | `labs/v2_07_operations_handover/` |
| PRAXORYN_SVAZEK_III_LAB_01.zip | `labs/v3_01_mediaops/` |
| PRAXORYN_STUDIO_LAB_02.zip | `labs/v3_02_studio/` |
| PRAXORYN_CODEOPS_LAB_03.zip | `labs/v3_03_codeops/` |
| PRAXORYN_OPSBRIDGE_LAB_04.zip | `labs/v3_04_opsbridge/` |
| PRAXORYN_FORGE_LAB_05.zip | `labs/v3_05_forge/` |
| PRAXORYN_LAUNCHKIT_LAB_06.zip | `labs/v3_06_launchkit/` |

## Compatibility notes

- All labs are reference implementations, not certified commercial products.
- Labs may include optional Python, PHP, MariaDB, Nginx, FFmpeg, and ComfyUI integration; installed dependencies vary by lab.
- Synthetic fixtures such as `case_487.txt` are deliberately not actual customer records.
- The Field Kit project is at `labs/v2_06_aiops_fieldkit/aiops-fieldkit/`; its documented entry point is `python -m aiops`.
- `CaseDesk` is at `labs/v2_05_casedesk/casedesk/`; `Forge` is at `labs/v3_05_forge/forge/`.
- Never copy example secrets into a real environment. Read each project's security section.
- Image generation and real GPU inference require separately installed, licensed model weights; offline mock outputs are not AI-generated.

Repository: https://github.com/Damian-Software/PRAXORYN
